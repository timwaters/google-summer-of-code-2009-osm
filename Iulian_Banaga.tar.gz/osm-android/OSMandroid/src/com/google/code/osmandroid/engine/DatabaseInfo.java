package com.google.code.osmandroid.engine;

public class DatabaseInfo {

	public static final String DATABASE_NAME = "OSMandroid";
	public static final String TABLE_NAME    = "addresses";

	public static final String DB_URL = "/data/data/com.google.code.osmandroid/databases/" + DATABASE_NAME;
}
