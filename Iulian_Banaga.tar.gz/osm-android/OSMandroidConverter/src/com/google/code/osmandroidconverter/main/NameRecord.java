package com.google.code.osmandroidconverter.main;

public class NameRecord {

	public int 		id;
	public String 	name;
	public String 	city;
	public int 		centerX;
	public int	 	centerY;
	public int		length;
	
}
