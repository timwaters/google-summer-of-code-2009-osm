<?php
class LayoutWithout extends Layout
{
	/**
	 * method puts image onto map image
	 * 
	 * @param Map  $map
	 * @param resources $imageToPut
	 */
	public function putImage(Map $map, $imageToPut)
	{	
	}
	
}