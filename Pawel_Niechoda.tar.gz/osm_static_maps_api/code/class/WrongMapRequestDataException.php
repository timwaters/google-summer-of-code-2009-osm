<?php
	
class WrongMapRequestDataException extends Exception 
{
	
}