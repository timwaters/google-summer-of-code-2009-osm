This is the final, and pretty polished application, built by cleaning various prototypes.
-----
Running the application:
Assuming you have Apache installed on Windows ( works on any OS - will host it up on Internet in near future ). In my case, I pasted the folder "Eurotriptalk" in htdocs folder, and then entering http://localhost/eurotriptalk/home.html on web browser's Address bar. This makes application alive. PLEASE NOTE, THE APPLICATION WORKS ONLY WHEN COMPUTER IS CONNECTED TO INTERNET. 
-----
Modules:
1- Directions tool with Routing Information for any Source to any Destination in Europe.
2- Point of Interests along Route and/or around Source/Destination in Europe.
3- Dynamic Talking Map, also helps browsing Point of Interests around any location in Europe.
4- Dynamic Map search, for partially visually impaired. 
-----
Prerequisites:
1- Firefox.
2- Outfox plug-in.
3- Google Gears.
-----
Work after 17th Aug (firm pencil's down date - GSoC'09):
The application was totally completed by 17th itself, except some polishing work. Like working on orsaudible.php to add more meaning to textual output.Fixed some minor issues mentioned on Google Code repository ( like modifying orspoi.php, relative/localhost links, bbox issue etc ) . 
------------------------------
PLEASE NOTE: The Google Gears implementation uses "modified/edited" sample code from Google Gears' website i.e. in Home.html, indexaudi.php and indexglobalmap.php .
------------------------------

For any issues/help, please email at vaish.rajan[at]gmail.com. 