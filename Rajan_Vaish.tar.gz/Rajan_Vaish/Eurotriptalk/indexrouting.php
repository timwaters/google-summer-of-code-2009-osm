<html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Directions tool with Routing Information for any Source to any Destination in Europe</title>
</head>
<body>
<br>
<form action="orsrouting.php" method="get">
<center><h3>Directions tool with Routing Information for any Source to any Destination in Europe</h3></center><br>
<center>
<b> Source </b> (e.g. Street, City or Lat, Long) <input type="text" name="source" />

<b> Destination </b> (e.g. Street, City or Lat, Long) <input type="text" name="desti" /></center>
<br>
<small><center>Tip : Narrow down search by adding Country in query or exact Latitude/Longitude ( when dublicacy exists ).</center></small>
<br>
<center><input type="submit" /></center>
</form>
<br>
<br>
<center>
<h4><a href="orsrouting.php?source=oxford,+united+kingdom&desti=london,+united+kingdom">Why not try long route from Oxford to London in UK? </a></h4>
<h4><a href="orsrouting.php?source=buckingham+palace,+london&desti=tower+of+london,+london">or may be, short route from famous Buckingham Palace to Tower of London in London? </a></h4>
</center>
<center>
<a href="http://openstreetmap.org">OSM</a>
<a href="http://openrouteservice.org/">ORS</a>
<a href="http://webanywhere.cs.washington.edu/wa.php">WebAnywhere</a>
</center>
<br><br>
</body>
</html>