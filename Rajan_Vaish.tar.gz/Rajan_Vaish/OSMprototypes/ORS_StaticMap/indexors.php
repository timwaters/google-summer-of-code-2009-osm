<html>
<body>
<form action="orsroutemap.php" method="get">
<center><h3>ORS for Visually Impaired with map(Simple prototype)</h3></center><br>
<center><b> Source </b> (e.g. Street,City) <input type="text" name="source" />

  <b> Destination </b> (e.g. Street,City) <input type="text" name="desti" /></center>
<br>
<small><center>Tip : Narrow down search by adding Country in query (when dublicacy exists).</center></small>
<br>
<center><input type="submit" /></center>
</form>
<center><a href="http://localhost/ors/indexors.php">Refresh</a>
<a href="http://openstreetmap.org">OSM</a>
<a href="http://openrouteservice.org/">ORS</a></center>
<br><br>
<small><center>Geocoding:ORS - Routing Engine:ORS</center></small>
</body>
</html>