<html>
<body>
<form action="routingors.php" method="get">
<center><h3>ORS for Visually Impaired with map(Simple prototype)</h3></center><br>
<center><b> Source </b> (e.g. Street,City) <input type="text" name="source" />

  <b> Destination </b> (e.g. Street,City) <input type="text" name="desti" /></center>
<br>
<small><center>Tip : Narrow down search by adding Country in query (when dublicacy exists).</center></small>
<br>
<center><input type="submit" /></center>
</form>
<center><a href="http://localhost/ors/indexors.php">Refresh</a>
<a href="http://openstreetmap.org">OSM</a>
<a href="http://openrouteservice.org/">ORS</a></center>
<br><br>
<small><center>Geocoding:ORS - Routing Engine:ORS Lat/Long along route:Gosmore/YOURS [the application could not be tested even once, due to down server of Gosmore]</center></small>
</body>
</html>