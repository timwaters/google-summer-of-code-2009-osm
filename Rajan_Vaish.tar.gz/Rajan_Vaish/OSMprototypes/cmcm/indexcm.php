<html>
<body>
<form action="routingcm.php" method="get">
<center><h3>CloudMade for Visually Impaired(Simple prototype)</h3></center><br>
<center><b> Source </b> (e.g. Street,City,Country) <input type="text" name="source" />

  <b> Destination </b> (e.g. Street,City,Country) <input type="text" name="desti" /></center>
<br>
<small><center>Tip: Use country,in query to avoid dublicacy and better results.</small></center>
<br>
<center><input type="submit" /></center>
</form>
<center><a href="http://localhost/cmcm/indexcm.php">Refresh</a>
<a href="http://openstreetmap.org">OSM</a>
<a href="http://developers.cloudmade.com/projects">CloudMade</a></center>
<br>
<br>
<small><center>Geocoding:CloudMade - Routing Engine:CloudMade</center></small>
</body>
</html>