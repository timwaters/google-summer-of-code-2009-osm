<html>
<body>
<form action="routingnamefinder.php" method="get">
<center><h3>Namefinder & CloudMade for Visually Impaired(Simple prototype)</h3></center><br>
<center><b> Source </b> (e.g. Street,City,Country) <input type="text" name="source" />

  <b> Destination </b> (e.g. Street,City,Country) <input type="text" name="desti" /></center>
<br>
<small><center>Tip: Use country,in query to avoid dublicacy and better results.</small></center>
<br>
<center><input type="submit" /></center>
</form>
<center><a href="http://localhost/nmcm/indexnamefinder.php">Refresh</a>
<a href="http://openstreetmap.org">OSM</a>
<a href="http://gazetteer.openstreetmap.org/namefinder/">Namefinder</a>
<a href="http://developers.cloudmade.com/projects">CloudMade</a></center>
<br>
<br>
<small><center>Geocoding:Namefinder - Routing Engine:CloudMade Web Maps lite</center></small>
</body>
</html>