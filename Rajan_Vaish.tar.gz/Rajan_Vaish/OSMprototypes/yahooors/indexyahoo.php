<html>
<body>
<form action="routingyahoo.php" method="get">
<center><h3>Yahoo! & ORS for Visually Impaired(Simple prototype)</h3></center><br>
<center><b> Source </b> (e.g. Street,City) <input type="text" name="source" />

  <b> Destination </b> (e.g. Street,City) <input type="text" name="desti" /></center>
<br>
<center><input type="submit" /></center>
</form>
<center><a href="http://localhost/yahooors/indexyahoo.php">Refresh</a>
<a href="http://openstreetmap.org">OSM</a>
<a href="http://openrouteservice.org">ORS</a>
<a href="http://developer.yahoo.com/geo/geoplanet/data/">Yahoo! Geoplanet Data</a></center>
<br>
<br>
<small><center>Geocoding:Yahoo! - Routing Engine:ORS</center></small>
</body>
</html>