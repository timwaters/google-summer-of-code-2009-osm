OSMPrototypes ( this is a collection of Experiments done during 1st phase of GSoC'09 and later, which was eventually improved to create polished application - Eurotriptalk )
Eurotripalk ( this is final polished application )
